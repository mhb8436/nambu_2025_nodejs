//
//  global.swift
//  Yangpa-app
//
//  Created by youngrok on 5/8/25.
//

let host = "https://yangpa-lyr.azurewebsites.net"
let blobURL = "https://styangpalyr113.blob.core.windows.net/cn-yangpa/"
