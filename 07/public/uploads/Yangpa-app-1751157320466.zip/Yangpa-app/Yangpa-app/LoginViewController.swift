//
//  LoginViewController.swift
//  Yangpa-app
//
//  Created by wizard on 5/7/25.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController {
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func actSignUp(_ sender: Any) {
        guard let userName = txtUserName.text,
              userName != "",
              let password = txtPassword.text,
              password != ""
        else {
            print("사용자명이나 비밀번호를 확인하시오.")
            return
        }
        let parameters: Parameters = ["userName":userName, "password":password]
        let strURL = "\(host)/members/sign-up"
        AF.request(strURL, method: .post, parameters: parameters)
            .responseDecodable(of: SignUp.self) { response in
                switch response.result {
                    case .success(let signUp):
                        let alert = UIAlertController(title: "회원가입", message: "\(signUp.member.userName)님 \(signUp.message)", preferredStyle: .alert)
                        let action = UIAlertAction(title: "확인", style: .default)
                        alert.addAction(action)
                        self.present(alert, animated: true);
                    case .failure(let error):
                        let alert = UIAlertController(title: "회원가입", message: error.localizedDescription, preferredStyle: .alert)
                        let action = UIAlertAction(title: "확인", style: .default)
                        alert.addAction(action)
                        self.present(alert, animated: true);
                }
            }
    }
    
    @IBAction func actSignIn(_ sender: Any) {
        guard let userName = txtUserName.text,
              userName != "",
              let password = txtPassword.text,
              password != ""
        else {
            print("사용자명이나 비밀번호를 확인하시오.")
            return
        }
        let parameters: Parameters = ["userName":userName, "password":password]
        let strURL = "\(host)/members/sign-in"
        AF.request(strURL, method: .post, parameters: parameters)
            .responseDecodable(of: SignIn.self) { response in
                switch response.result {
                    case .success(let signIn):
                        UserDefaults.standard.set(signIn.token, forKey: "token")
                        UserDefaults.standard.set(true, forKey: "isLoggedIn")
                        UserDefaults.standard.set(signIn.member.userName, forKey: "userName")
                        let alert = UIAlertController(title: "로그인", message: "\(signIn.member.userName)님 \(signIn.message)", preferredStyle: .alert)
                        let action = UIAlertAction(title: "확인", style: .default) { _ in
                            self.dismiss(animated: true)
                        }
                        alert.addAction(action)
                        self.present(alert, animated: true);
                    case .failure(let error):
                        let alert = UIAlertController(title: "로그인", message: error.localizedDescription, preferredStyle: .alert)
                        let action = UIAlertAction(title: "확인", style: .default)
                        alert.addAction(action)
                        self.present(alert, animated: true);
                }
            }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
