//
//  DetailViewController.swift
//  Yangpa-app
//
//  Created by wizard on 5/7/25.
//

import UIKit
import Alamofire
import Kingfisher

class DetailViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var txtDesc: UITextView!
    var saleID:Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        getSaleById(saleID)
        // Do any additional setup after loading the view.
    }
    
    func updateUI(_ document: Document) {
        let url = URL(string:"\(blobURL)\(document.photo)")
        self.imageView.kf.setImage(with: url)
        self.lblName.text = document.productName
        self.lblPrice.text = "\(document.price)원"
        self.txtDesc.text = document.description
    }
    
    func getSaleById(_ id:Int?){
        guard let id
        else {
            print("id를 확인하세요.")
            return
        }
        let endPoint = "\(host)/sales/\(id)"
        guard let token = UserDefaults.standard.string(forKey: "token")
        else {
            print("login 하시오.")
            return
        }
        let headers:HTTPHeaders = ["Authorization":"Bearer \(token)"]
        AF.request(endPoint, headers: headers)
            .responseDecodable(of:Root.self) { response in
                switch response.result {
                case .success(let root):
                    guard let document = root.documents.first else { return }
                    DispatchQueue.main.async {
                        self.updateUI(document)
                    }
                case .failure(let error):
                    print("디코딩 실패")
                }
            }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
