//
//  Model.swift
//  Yangpa-app
//
//  Created by wizard on 5/7/25.
//

struct Member: Codable {
    let userName: String
}

struct SignUp: Codable {
    let success: Bool
    let member: Member
    let message: String
}

struct SignIn: Codable {
    let success: Bool
    let member: Member
    let message: String
    let token: String
}

struct Document: Codable {
    let id: Int
    let productName: String
    let description: String
    let price: Int
    let photo: String
    let userName: String
}

struct Root: Codable {
    let success: Bool
    let documents: [Document]
    let message: String
}
