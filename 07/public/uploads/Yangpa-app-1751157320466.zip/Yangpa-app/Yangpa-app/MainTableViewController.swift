//
//  MainTableViewController.swift
//  Yangpa-app
//
//  Created by wizard on 5/7/25.
//

import UIKit
import Alamofire
import Kingfisher

class MainTableViewController: UITableViewController {
    var documents:[Document]?
    override func viewDidLoad() {
        super.viewDidLoad()
        let isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
        if !isLoggedIn {
            if let loginVC = storyboard?.instantiateViewController(withIdentifier: "login") as? LoginViewController {
                loginVC.modalPresentationStyle = .fullScreen
                present(loginVC, animated: true)
            }
        }
        
        getSales()
    }
    
    func getSales(){
        guard let token = UserDefaults.standard.string(forKey: "token")
        else {
            print("로그인하시오")
            return
        }
        let endPoint = "\(host)/sales"
        let headers:HTTPHeaders = ["Authorization": "Bearer \(token)"]
        AF.request(endPoint, method: .get, headers: headers)
            .responseDecodable(of:Root.self) { response in
                switch response.result {
                    case .success(let root):
                        self.documents = root.documents

                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    case .failure(let error):
                        print(error.localizedDescription)
                }
            }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return documents?.count ?? 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sale", for: indexPath)
        
        guard let documents else { return cell }
        let document = documents[indexPath.row]
        print(document)
        let imageView = cell.viewWithTag(1) as? UIImageView
        let lblName = cell.viewWithTag(2) as? UILabel
        let lblDesc = cell.viewWithTag(3) as? UILabel
        let lblPrice = cell.viewWithTag(4) as? UILabel
        let lblUser = cell.viewWithTag(5) as? UILabel
        let imageURL = "\(blobURL)\(document.photo)"
        imageView?.kf.setImage(with: URL(string:imageURL))
        lblName?.text = document.productName
        lblDesc?.text = document.description
        lblPrice?.text = "\(document.price)원"
        lblUser?.text = document.userName

        return cell
    }
   

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let detailVC = segue.destination as? DetailViewController
        guard let indexPath = tableView.indexPathForSelectedRow,
              let documents
        else { return }
        let selected = documents[indexPath.row]
        detailVC?.saleID = selected.id
    }
    

}
