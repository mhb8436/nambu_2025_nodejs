//
//  StateTestView.swift
//  StateBindingTest
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct StateTestView: View {
    @State var isOn = false
  
    var body: some View {
        Image(systemName: isOn ? "lightbulb" : "lightbulb.fill" )
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 100)
            .padding(.bottom, 20)
        
        Button {
            isOn.toggle()
        } label: {
            if isOn {
                Text("OFF")
                   
            } else {
                Text("On")
                   
            }
        } .bold()
            .font(.title2)
            .padding()
            .padding(.horizontal, 20)
            .background(.red)
            .clipShape(RoundedRectangle(cornerRadius: 10))

    }
}

#Preview {
    StateTestView()
}
