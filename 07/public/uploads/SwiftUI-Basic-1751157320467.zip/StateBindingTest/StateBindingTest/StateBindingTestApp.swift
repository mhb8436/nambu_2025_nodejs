//
//  StateBindingTestApp.swift
//  StateBindingTest
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

@main
struct StateBindingTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
