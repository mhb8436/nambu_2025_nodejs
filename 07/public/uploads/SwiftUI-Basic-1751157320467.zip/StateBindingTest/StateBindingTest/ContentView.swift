//
//  ContentView.swift
//  StateBindingTest
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct ContentView: View {
    @State var framework = "Hello UIKit"
    var body: some View {
        VStack {
            Text(framework)
                .font(.largeTitle)
                .bold()
            Button {
                framework = "Hello SwiftUI"
            } label: {
                Text("Framework 변경")
                    .bold()
                    .padding(.horizontal, 10)
                    .padding(.top, 10)
                
            }
            
            Button {
                framework = "Hello UIKit"
            } label: {
                Text("Framework 변경")
                    .bold()
                    .padding(.horizontal, 10)
                    .padding(.top, 10)
                
            }

        }
        .padding()
    }
}

#Preview {
    ContentView()
}
