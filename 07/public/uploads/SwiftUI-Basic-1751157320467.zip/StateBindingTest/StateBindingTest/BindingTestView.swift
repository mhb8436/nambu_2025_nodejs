//
//  BindingTestView.swift
//  StateBindingTest
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct BindingTestView: View {
    @State private var isOn = true
    var body: some View {
        Toggle(isOn: $isOn) {
            Text("켜고 끄기")
        }.padding()
        
       WifiImageView(isOn: $isOn)
    }
}

struct WifiImageView:View {
    @Binding var isOn: Bool
    var body: some View {
        Image(systemName: isOn ? "wifi" : "wifi.slash")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 50)
    }
}
#Preview {
    BindingTestView()
}
