//
//  VStackTest.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct VStackTest: View {
    var body: some View {
        VStack(alignment:.center) {
            VStack{
                Text("Hello World")
                    .padding(20)
                    .background(.red)
            }
        }
        
        VStack(alignment:.leading) {
            Text("Hello World")
                .padding(20)
                .background(.blue)
            Text("Hello World!!!!!!!")
                .padding(20)
                .background(.blue)
        }
    }
}

#Preview {
    VStackTest()
}
