//
//  ImageTestView.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct ImageTestView: View {
    var body: some View {
        Image("SwiftUI")
        Image("SwiftUI")
            .resizable()
            .frame(width: 300, height: 300)
    }
}

#Preview {
    ImageTestView()
}
