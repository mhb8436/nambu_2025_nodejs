//
//  HelloSwiftUIApp.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

@main
struct HelloSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
