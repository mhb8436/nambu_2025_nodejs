//
//  ContentView.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
      
            Text("Hello SwiftUI")
            Text("Hello SwiftUI")
                .font(.largeTitle)
                .bold()
                .foregroundStyle(.red)
                .padding()
                .background(.blue)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            Text("Hello 오이영")
            ImageTestView()
            ButtonTestView()
      
    }
}

#Preview {
    ContentView()
}
