//
//  ButtonTestView.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct ButtonTestView: View {
    var body: some View {
        Button {
            print("Button이 눌러짐")
        } label: {
            Text("Button")
                .font(.headline)
                .bold()
                .foregroundStyle(.red)
                .padding()
                .background(.blue)
                .clipShape(RoundedRectangle(cornerRadius: 5))
        }
        
        Button("Button", image: .swiftUI) {
            print("두번째 버튼 눌러짐")
        }

    }
}

#Preview {
    ButtonTestView()
}
