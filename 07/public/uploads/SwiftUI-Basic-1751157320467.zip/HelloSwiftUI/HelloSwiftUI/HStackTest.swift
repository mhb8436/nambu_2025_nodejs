//
//  HStackTest.swift
//  HelloSwiftUI
//
//  Created by youngrok on 5/8/25.
//

import SwiftUI

struct HStackTest: View {
    var body: some View {
        HStack(alignment: .bottom, spacing: 20) {
            Text("Hello World")
                .padding(20)
                .background(.blue)
            Text("Hello World!!!!!!!")
                .padding(30)
                .background(.blue)
        }
    }
}

struct ZStackTest: View {
    var body: some View {
        ZStack {
            Text("Hello World!!!!!!!")
                .padding(50)
                .background(.blue)
            Text("Hello World!!!!!!!")
                .padding(30)
                .background(.yellow)
        }
       
    }
}

#Preview {
    ZStackTest()
}
