# 04 - useEffect

라이프사이클 훅 useEffect를 사용한 시계 예제입니다.