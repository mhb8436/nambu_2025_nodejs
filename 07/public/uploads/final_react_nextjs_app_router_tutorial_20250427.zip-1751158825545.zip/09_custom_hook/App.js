import useCounter from './useCounter';

function App() {
  const { count, increment, decrement } = useCounter();
  return (
    <div>
      <p>Custom Hook Count: {count}</p>
      <button onClick={increment}>+</button>
      <button onClick={decrement}>-</button>
    </div>
  );
}

export default App;