import Message from './components/Message';

function App() {
  return <Message text="Component 분리 예제" />;
}

export default App;