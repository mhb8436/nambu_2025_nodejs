export default function Message({ text }) {
  return <p>{text}</p>;
}