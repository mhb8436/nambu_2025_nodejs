# 06 - useRef

useRef를 이용하여 DOM 요소에 접근하는 예제입니다.