export default function AboutPage() {
  return <h1>About Page (App Router)</h1>;
}