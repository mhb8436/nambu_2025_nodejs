# 12 - App Router 중첩 라우팅

폴더를 만들고 그 안에 `page.tsx`를 추가하면 중첩 라우팅이 됩니다.