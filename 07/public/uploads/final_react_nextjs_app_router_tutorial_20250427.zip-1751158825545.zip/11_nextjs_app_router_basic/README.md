# 11 - App Router 기본

`app/page.tsx` 파일이 루트 페이지가 됩니다.