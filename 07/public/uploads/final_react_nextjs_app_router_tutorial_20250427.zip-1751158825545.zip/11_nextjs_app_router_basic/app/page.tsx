export default function HomePage() {
  return <h1>Home Page (App Router)</h1>;
}