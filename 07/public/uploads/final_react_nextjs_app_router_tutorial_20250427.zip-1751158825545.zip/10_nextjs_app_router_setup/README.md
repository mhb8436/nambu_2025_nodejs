# 10 - Next.js App Router Setup

Next.js 13+ App Router 기반 세팅 방법

```bash
npx create-next-app@latest my-app --typescript --eslint --tailwind --app
cd my-app
npm run dev
```