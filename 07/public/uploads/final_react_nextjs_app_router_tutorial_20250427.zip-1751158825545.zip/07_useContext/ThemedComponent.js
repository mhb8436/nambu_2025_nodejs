import React, { useContext } from 'react';
import { ThemeContext } from './context/ThemeContext';

export default function ThemedComponent() {
  const theme = useContext(ThemeContext);
  return <p>Current Theme: {theme}</p>;
}