# 07 - useContext

Context API와 useContext 훅을 사용하는 예제입니다.