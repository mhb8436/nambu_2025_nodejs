import React from 'react';
import { ThemeContext } from './context/ThemeContext';
import ThemedComponent from './ThemedComponent';

function App() {
  return (
    <ThemeContext.Provider value="dark">
      <ThemedComponent />
    </ThemeContext.Provider>
  );
}

export default App;