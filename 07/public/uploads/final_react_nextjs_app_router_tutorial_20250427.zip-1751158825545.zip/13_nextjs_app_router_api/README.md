# 13 - API Routes (App Router)

`app/api/` 안에 라우트 파일을 만들어 API를 작성합니다.