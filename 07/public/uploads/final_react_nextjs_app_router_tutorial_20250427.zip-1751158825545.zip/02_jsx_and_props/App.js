function Welcome(props) {
  return <h1>Hello, {props.name}</h1>;
}

export default function App() {
  return <Welcome name="React" />;
}