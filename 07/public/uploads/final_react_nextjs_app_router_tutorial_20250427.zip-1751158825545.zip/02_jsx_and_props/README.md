# 02 - JSX & Props

JSX 문법과 Props 전달 예제입니다.