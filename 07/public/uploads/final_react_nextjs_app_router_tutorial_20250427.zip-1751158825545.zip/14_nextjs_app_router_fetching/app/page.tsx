async function getData() {
  return { message: 'Hello from Server' };
}

export default async function HomePage() {
  const data = await getData();
  return <h1>{data.message}</h1>;
}