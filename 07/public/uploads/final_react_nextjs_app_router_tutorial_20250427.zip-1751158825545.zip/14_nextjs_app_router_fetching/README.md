# 14 - 데이터 패칭 (App Router)

Server Component에서 데이터를 await로 받아옵니다.