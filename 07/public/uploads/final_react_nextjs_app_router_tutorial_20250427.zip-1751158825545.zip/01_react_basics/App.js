import React from 'react';

function App() {
  return <h1>Hello React!</h1>;
}

export default App;